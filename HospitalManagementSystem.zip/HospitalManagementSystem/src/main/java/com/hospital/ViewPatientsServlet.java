package com.hospital;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/ViewPatientsServlet")
public class ViewPatientsServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Set content type
        response.setContentType("text/html;charset=UTF-8");

        try {
            // Load MySQL JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Connect to database
            Connection con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/hospitaldb", "root", "rohit@2004");

            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM patients");

            // Build HTML table
            StringBuilder html = new StringBuilder();
            html.append("<html><head><title>Patient List</title>")
                .append("<style>")
                .append("table {border-collapse: collapse; width: 70%; margin: 20px auto;}")
                .append("th, td {border: 1px solid #ddd; padding: 8px; text-align: center;}")
                .append("th {background-color: #2f80ed; color: white;}")
                .append("h2 {text-align: center;}")
                .append("</style></head><body>");
            html.append("<h2>Patient List</h2>");
            html.append("<table><tr><th>ID</th><th>Name</th><th>Age</th><th>Gender</th></tr>");

            while (rs.next()) {
                html.append("<tr>")
                    .append("<td>").append(rs.getInt("id")).append("</td>")
                    .append("<td>").append(rs.getString("name")).append("</td>")
                    .append("<td>").append(rs.getInt("age")).append("</td>")
                    .append("<td>").append(rs.getString("gender")).append("</td>")
                    .append("</tr>");
            }

            html.append("</table></body></html>");

            // Send HTML response
            response.getWriter().print(html.toString());

            // Close resources
            rs.close();
            stmt.close();
            con.close();

        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().print("<h3>Error: " + e.getMessage() + "</h3>");
        }
    }
}
