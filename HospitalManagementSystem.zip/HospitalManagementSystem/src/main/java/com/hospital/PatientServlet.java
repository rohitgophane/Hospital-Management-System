package com.hospital;

import java.io.IOException;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/PatientServlet")
public class PatientServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private static final String URL = "jdbc:mysql://localhost:3306/hospitaldb";
    private static final String USER = "root";
    private static final String PASS = "rohit@2004";

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");
        if (action == null) action = "view";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(URL, USER, PASS);

            if ("add".equals(action)) {
                // Read form fields
                String name = request.getParameter("name");
                String age = request.getParameter("age");
                String gender = request.getParameter("gender");
                String phone = request.getParameter("phone");
                String address = request.getParameter("address");

                // Insert patient
                String sql = "INSERT INTO patients (name, age, gender, phone, address) VALUES (?, ?, ?, ?, ?)";
                PreparedStatement ps = con.prepareStatement(sql);
                ps.setString(1, name);
                ps.setInt(2, Integer.parseInt(age));
                ps.setString(3, gender);
                ps.setString(4, phone);
                ps.setString(5, address);
                ps.executeUpdate();
                ps.close();

                // Redirect to view list
                response.sendRedirect("PatientServlet?action=view");

            } else if ("view".equals(action)) {
                // Forward to JSP for showing patients
                request.getRequestDispatcher("viewPatients.jsp").forward(request, response);
            }

            con.close();
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Error: " + e.getMessage());
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
}
