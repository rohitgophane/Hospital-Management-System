package com.hospital;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;
import java.sql.*;
import java.util.*;

@WebServlet("/AppointmentServlet")
public class AppointmentServlet extends HttpServlet {

    private static final String DB_URL = "jdbc:mysql://localhost:3306/hospitaldb";
    private static final String DB_USER = "root";
    private static final String DB_PASS = "rohit@2004";

    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {

        String action = request.getParameter("action");

        if ("book".equalsIgnoreCase(action)) {
            try {
                int patientId = Integer.parseInt(request.getParameter("patient_id"));
                int doctorId = Integer.parseInt(request.getParameter("doctor_id"));
                String date = request.getParameter("date");
                String time = request.getParameter("time");

                Class.forName("com.mysql.cj.jdbc.Driver");
                Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);

                PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO appointments (patient_id, doctor_id, date, time, status) VALUES (?, ?, ?, ?, ?)"
                );
                ps.setInt(1, patientId);
                ps.setInt(2, doctorId);
                ps.setString(3, date);
                ps.setString(4, time);
                ps.setString(5, "Pending");

                ps.executeUpdate();
                ps.close();
                con.close();

                request.setAttribute("message", "Appointment booked successfully!");
                RequestDispatcher rd = request.getRequestDispatcher("appointment.jsp");
                rd.forward(request, response);

            } catch (Exception e) {
                e.printStackTrace();
                request.setAttribute("message", "Error booking appointment: " + e.getMessage());
                RequestDispatcher rd = request.getRequestDispatcher("appointment.jsp");
                rd.forward(request, response);
            }

        } else if ("view".equalsIgnoreCase(action)) {
            List<Map<String, String>> appointments = new ArrayList<>();
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);

                Statement st = con.createStatement();
                ResultSet rs = st.executeQuery(
                    "SELECT a.id, p.name AS patient, d.name AS doctor, a.date, a.time, a.status " +
                    "FROM appointments a " +
                    "JOIN patients p ON a.patient_id = p.id " +
                    "JOIN doctors d ON a.doctor_id = d.id"
                );

                while (rs.next()) {
                    Map<String, String> row = new HashMap<>();
                    row.put("id", rs.getString("id"));
                    row.put("patient", rs.getString("patient"));
                    row.put("doctor", rs.getString("doctor"));
                    row.put("date", rs.getString("date"));
                    row.put("time", rs.getString("time"));
                    row.put("status", rs.getString("status"));
                    appointments.add(row);
                }

                rs.close();
                st.close();
                con.close();

                request.setAttribute("appointments", appointments);
                RequestDispatcher rd = request.getRequestDispatcher("viewAppointments.jsp");
                rd.forward(request, response);

            } catch (Exception e) {
                e.printStackTrace();
                request.setAttribute("message", "Error fetching appointments: " + e.getMessage());
                RequestDispatcher rd = request.getRequestDispatcher("appointment.jsp");
                rd.forward(request, response);
            }
        } else {
            response.sendRedirect("appointment.jsp");
        }
    }
}
